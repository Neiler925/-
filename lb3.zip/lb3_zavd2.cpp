#include <iostream>
using namespace std;
int main ()
{
	setlocale (LC_CTYPE,"");
	int code;
	cout<<"����i�� ���������� ���"<<endl;
	cin>>code;
	switch(code)
	{
		case 50:
			cout<<"Vodafone"<<endl;
			break;
		case 63:
			cout<<"Life:)"<<endl;
			break;
		case 67:
			cout<<"KYIVSTAR"<<endl;
			break;
		case 68:
			cout<<"KYIVSTAR"<<endl;
			break;
		case 93:
			cout<<"Life:)"<<endl;
			break;
		case 98:
			cout<<"KYIVSTAR"<<endl;
			break;
		case 99:
			cout<<"Vodafone"<<endl;
			break;
	}
}
